
document.getElementById("footer-year").innerText = `${new Date().getFullYear()} Mateus Navarro`;